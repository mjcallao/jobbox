angular.module('main').controller("profileCtrl",[ "$scope", function($scope){
    $scope.profile="profile"
}]);